/**
 * content.js
 * Chức năng chính: Tạo một nút bấm và một popup iframe.
 * Khi bấm, nút sẽ hiển thị/ẩn popup chứa giao diện tạo mã 2FA.
 */

let popupIframe = null;

// Hàm tạo nút bấm
function createToggleButton() {
    const button = document.createElement('button');
    button.id = 'two-fa-ext-toggle-button';
    button.textContent = '🔑';
    button.title = 'Mở/Đóng trình tạo mã 2FA';
    document.body.appendChild(button);

    button.addEventListener('click', (e) => {
        // Ngăn sự kiện click lan ra ngoài, tránh việc popup tự đóng ngay lập tức
        e.stopPropagation();
        togglePopup();
    });
}

// Hàm hiển thị/ẩn popup
function togglePopup() {
    // Nếu popup đang tồn tại, hãy xóa nó đi
    if (popupIframe && document.body.contains(popupIframe)) {
        popupIframe.remove();
        popupIframe = null;
        return;
    }

    // Nếu không, tạo mới popup
    popupIframe = document.createElement('iframe');
    popupIframe.id = 'two-fa-popup-iframe';
    popupIframe.src = chrome.runtime.getURL('2fa-generator.html');
    document.body.appendChild(popupIframe);
}

// Ẩn popup khi người dùng bấm ra ngoài
document.addEventListener('click', () => {
    if (popupIframe && document.body.contains(popupIframe)) {
        popupIframe.remove();
        popupIframe = null;
    }
});


// === PHẦN CẬP NHẬT ===
// Lắng nghe thông điệp từ iframe để điều chỉnh chiều cao
window.addEventListener('message', (event) => {
    const data = event.data;
    // Kiểm tra xem có phải thông điệp thay đổi kích thước không và popup có đang tồn tại không
    if (data && data.type === 'resize-2fa-popup' && popupIframe) {
        // Cập nhật chiều cao của iframe, thêm một chút đệm để tránh thanh cuộn
        const newHeight = data.height + 50;
        popupIframe.style.height = `${newHeight}px`;
    }
});

// Chạy hàm tạo nút khi trang đã sẵn sàng
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createToggleButton);
} else {
    createToggleButton();
}

