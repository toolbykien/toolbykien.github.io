/**
 * jsOTP v3.0.0 (Corrected)
 * A JavaScript library for generating one-time passwords according to RFC 4226 and RFC 6238.
 * This version contains a corrected SHA-1 implementation for accurate OTP generation.
 */

var jsOTP = (function(global) {
    'use strict';

    var jsOTP = {};
    jsOTP.totp = function() {};

    /**
     * Correctly pads a number to a string of a given length with leading zeros.
     * @param {number} num The number to pad.
     * @param {number} length The desired length of the string.
     * @returns {string} The padded string.
     */
    function pad(num, length) {
        var s = num.toString();
        while (s.length < length) {
            s = '0' + s;
        }
        return s;
    }

    /**
     * Base32 decoding.
     * @param {string} secret The Base32 encoded secret.
     * @returns {Uint8Array} The decoded secret as a byte array.
     */
    function base32toBuf(secret) {
        var charmap = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        secret = secret.toUpperCase().replace(/ /g, '').replace(/=/g, '');

        var buf = new Uint8Array(Math.ceil(secret.length * 5 / 8));
        var bits = 0;
        var bitLength = 0;
        var bufIndex = 0;

        for (var i = 0; i < secret.length; i++) {
            var val = charmap.indexOf(secret.charAt(i));
            if (val === -1) throw new Error("Invalid Base32 character found");

            bits = (bits << 5) | val;
            bitLength += 5;

            if (bitLength >= 8) {
                buf[bufIndex++] = (bits >>> (bitLength - 8)) & 0xFF;
                bitLength -= 8;
            }
        }
        return buf.slice(0, bufIndex); // Use slice to get the correct length
    }

    /**
     * A correct and robust SHA-1 implementation in pure JavaScript.
     * @param {Uint8Array} message The message to hash.
     * @returns {ArrayBuffer} The 20-byte SHA-1 hash.
     */
    function sha1(message) {
        function rotl(n, s) {
            return (n << s) | (n >>> (32 - s));
        }

        function toBigEndian(n) {
            return ((n & 0xff) << 24) | ((n & 0xff00) << 8) | ((n >>> 8) & 0xff00) | ((n >>> 24) & 0xff);
        }

        var H = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0];
        var K = [0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6];

        var T, A, B, C, D, E, W = [];
        var messageLen = message.length;
        var wordCount = Math.ceil((messageLen + 9) / 64) * 16;
        var words = new Uint32Array(wordCount);

        for (var i = 0; i < messageLen; i++) {
            words[i >>> 2] |= message[i] << (24 - (i % 4) * 8);
        }
        words[messageLen >>> 2] |= 0x80 << (24 - (messageLen % 4) * 8);
        words[wordCount - 1] = messageLen * 8;

        for (var j = 0; j < words.length; j += 16) {
            A = H[0]; B = H[1]; C = H[2]; D = H[3]; E = H[4];
            for (var i = 0; i < 80; i++) {
                if (i < 16) {
                    W[i] = words[j + i];
                } else {
                    W[i] = rotl(W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16], 1);
                }

                if (i < 20) {
                    T = (rotl(A, 5) + ((B & C) | (~B & D)) + E + W[i] + K[0]) | 0;
                } else if (i < 40) {
                    T = (rotl(A, 5) + (B ^ C ^ D) + E + W[i] + K[1]) | 0;
                } else if (i < 60) {
                    T = (rotl(A, 5) + ((B & C) | (B & D) | (C & D)) + E + W[i] + K[2]) | 0;
                } else {
                    T = (rotl(A, 5) + (B ^ C ^ D) + E + W[i] + K[3]) | 0;
                }
                E = D; D = C; C = rotl(B, 30); B = A; A = T;
            }
            H[0] = (H[0] + A) | 0;
            H[1] = (H[1] + B) | 0;
            H[2] = (H[2] + C) | 0;
            H[3] = (H[3] + D) | 0;
            H[4] = (H[4] + E) | 0;
        }

        var result = new ArrayBuffer(20);
        var view = new DataView(result);
        for (var i = 0; i < 5; i++) {
            view.setUint32(i * 4, H[i]);
        }
        return result;
    }

    /**
     * HMAC-SHA1 implementation.
     * @param {Uint8Array} key The secret key.
     * @param {Uint8Array} message The message to hash.
     * @returns {Uint8Array} The HMAC-SHA1 hash.
     */
    function hmacSha1(key, message) {
        var blockSize = 64;
        
        if (key.length > blockSize) {
            key = new Uint8Array(sha1(key));
        }
        if (key.length < blockSize) {
            var tempKey = new Uint8Array(blockSize);
            tempKey.set(key, 0);
            key = tempKey;
        }

        var o_key_pad = new Uint8Array(blockSize);
        var i_key_pad = new Uint8Array(blockSize);
        var concatenated = new Uint8Array(blockSize + message.length);

        for (var i = 0; i < blockSize; i++) {
            o_key_pad[i] = key[i] ^ 0x5c;
            i_key_pad[i] = key[i] ^ 0x36;
        }
        
        concatenated.set(i_key_pad, 0);
        concatenated.set(message, blockSize);
        var innerHash = new Uint8Array(sha1(concatenated));

        concatenated = new Uint8Array(blockSize + innerHash.length);
        concatenated.set(o_key_pad, 0);
        concatenated.set(innerHash, blockSize);
        
        return new Uint8Array(sha1(concatenated));
    }

    /**
     * Generates a TOTP code.
     * @param {string} secret The Base32 encoded secret.
     * @returns {string} The 6-digit TOTP code.
     */
    jsOTP.totp.prototype.getOtp = function(secret) {
        try {
            var period = 30;
            var digits = 6;
            
            var key = base32toBuf(secret);
            var epoch = Math.floor(Date.now() / 1000);
            var timeStep = Math.floor(epoch / period);

            var timeBytes = new Uint8Array(8);
            var view = new DataView(timeBytes.buffer);
            view.setUint32(4, timeStep, false); // Big Endian

            var hmac = hmacSha1(key, timeBytes);
            
            var offset = hmac[hmac.length - 1] & 0x0f;
            
            var dataView = new DataView(hmac.buffer, offset, 4);
            var code = (dataView.getUint32(0) & 0x7fffffff);
            
            var otp = code % Math.pow(10, digits);
            
            return pad(otp, digits);
        } catch (e) {
            console.error("Error in getOtp:", e);
            throw e;
        }
    };

    return jsOTP;
}(this));

