// Lấy các phần tử HTML cần dùng
const secretKeyInput = document.getElementById('secretKey');
const outputDiv = document.getElementById('output');
const otpCodeP = document.getElementById('otpCode');
const timeLeftSpan = document.getElementById('timeLeft');
const progressBar = document.getElementById('progressBar');
const errorMessageP = document.getElementById('errorMessage');
const copyFeedback = document.getElementById('copyFeedback');

let otpInterval = null;
let copyTimeout = null;
const totp = new jsOTP.totp();

// === PHẦN CẬP NHẬT: Logic gửi chiều cao được cải tiến ===

// Hàm gửi chiều cao của nội dung cho tệp content.js
function sendPopupHeight() {
    // Dùng requestAnimationFrame để đảm bảo trình duyệt đã vẽ xong trước khi đo
    requestAnimationFrame(() => {
        // SỬA LỖI: Đo trực tiếp container chính thay vì toàn bộ document
        const mainContainer = document.getElementById('main-container');
        if (mainContainer) {
            const height = mainContainer.offsetHeight;
            window.parent.postMessage({
                type: 'resize-2fa-popup',
                height: height
            }, '*');
        }
    });
}

// Hàm chính để tạo và hiển thị mã OTP
function generateAndDisplayOtp() {
    if (otpInterval) clearInterval(otpInterval);
    otpInterval = null;

    const secret = secretKeyInput.value.replace(/\s/g, '').toUpperCase();
    
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.set({ 'totp_secret_key': secret });
    }

    // Ghi lại trạng thái hiển thị của #output trước khi thay đổi
    const wasOutputHidden = outputDiv.classList.contains('hidden');

    if (!secret) {
        outputDiv.classList.add('hidden');
        errorMessageP.textContent = '';
        // Chỉ gửi chiều cao nếu trạng thái hiển thị thực sự thay đổi
        if (!wasOutputHidden) {
            sendPopupHeight();
        }
        return;
    }

    const base32Regex = /^[A-Z2-7]+=*$/;
    if (!base32Regex.test(secret)) {
        outputDiv.classList.add('hidden');
        errorMessageP.textContent = 'Chỉ chứa ký tự A-Z và 2-7.';
        if (!wasOutputHidden) {
            sendPopupHeight();
        }
        return;
    }

    outputDiv.classList.remove('hidden');
    errorMessageP.textContent = '';

    // Chỉ gửi chiều cao nếu trạng thái hiển thị thực sự thay đổi
    if (wasOutputHidden) {
        sendPopupHeight();
    }

    try {
        const updateUI = () => {
            const token = totp.getOtp(secret);
            const timeLeft = 30 - (Math.floor(Date.now() / 1000) % 30);
            const progressPercentage = (timeLeft / 30) * 100;

            otpCodeP.textContent = `${token.slice(0, 3)} ${token.slice(3, 6)}`;
            timeLeftSpan.textContent = timeLeft;
            progressBar.style.width = `${progressPercentage}%`;
        };

        updateUI();
        otpInterval = setInterval(updateUI, 1000);

    } catch (error) {
        console.error("Lỗi khởi tạo OTP:", error);
        outputDiv.classList.add('hidden');
        errorMessageP.textContent = 'Mã không hợp lệ. Kiểm tra lại.';
        // Gửi lại chiều cao vì giao diện đã thay đổi
        if (!wasOutputHidden) {
            sendPopupHeight();
        }
    }
}

// Sự kiện 'click' để sao chép mã
otpCodeP.addEventListener('click', () => {
    const code = otpCodeP.textContent.replace(/\s/g, '');
    if (code && code !== '------') {
        const textArea = document.createElement('textarea');
        textArea.value = code;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            copyFeedback.classList.remove('hidden');
            if (copyTimeout) clearTimeout(copyTimeout);
            copyTimeout = setTimeout(() => {
                copyFeedback.classList.add('hidden');
            }, 1500);
        } catch (err) {
            console.error('Không thể sao chép mã:', err);
        }
        document.body.removeChild(textArea);
    }
});

// Lắng nghe sự kiện input
secretKeyInput.addEventListener('input', generateAndDisplayOtp);

// Tải mã bí mật đã lưu và gửi chiều cao ban đầu
document.addEventListener('DOMContentLoaded', () => {
    // Đảm bảo chiều cao của body và html dựa trên nội dung, không phải khung nhìn.
    document.documentElement.style.height = 'auto';
    document.body.style.height = 'auto';

    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get('totp_secret_key', function(data) {
            if (data.totp_secret_key) {
                secretKeyInput.value = data.totp_secret_key;
                generateAndDisplayOtp();
            }
        });
    }
    // Gửi chiều cao ban đầu sau khi mọi thứ đã sẵn sàng
    sendPopupHeight();
});

